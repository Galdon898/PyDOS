import platform
PyDOSversion = '0.97'
pyver = str(platform.python_version)
print("-------------------------------------------------------------")
print("STARTING PyDOS, VERSION: " + PyDOSversion + " Please Wait.")
print("-------------------------------------------------------------")
print("Running on: " + pyver)
print("-------------------------------------------------------------")

#Libraries:
import sys
import os
import time
import random
import openai
from tkinter import *
import json
import webbrowser
import numpy as np
import ctypes
import requests
import pip
import typing_extensions
import cmd
from docx import Document
#OS Functions:

def ADMIN():
    if os.name == 'nt':
        if not ctypes.windll.shell32.IsUserAnAdmin():
            print("Please run the script as an administrator.")
            sys.exit()
    else:
        if os.geteuid() != 0:
            print("Please run the script as root/administrador.")
            sys.exit()

def PyDOS_file():
    file_name = "config"
    with open(file_name + '.PyDOSf', 'w') as file:
     file.write(f"PyDOS Version = " + PyDOSversion)
    #print("File created successfully!")

PyDOS_file()
#ADMIN()                                                                               ### DEBUG ONLY ###     
#PyFunctions:

def WEB():                   #DONE
    user_input_web = str(input("PUT THE NAME OF A WEB WITHOUT 'HTPPS://' OR '.COM' : "))
    url = 'https://' + user_input_web + '.com'
    webbrowser.open(url)
    print("WEB OPENED!")
    time.sleep(0.256)
    START1()

def EXIT():                  #DONE
    sys.exit()         

def START():                 #DONE
    print(f"Welcome to PyDOS! by Gael Rocca | " + PyDOSversion)            #VERSION
    print("-----------------------------------------")
    print("Type HELP to see the commands")
    print("-----------------------------------------")
    uinp = str(input("What do you want to do?: "))
    if uinp == "CREATE FOLDER":
        CREATE_FOLDER()
    elif uinp == "DELETE FOLDER":
        DELETE_FOLDER()
    elif uinp == "DIR":
        DIR()
    elif uinp == "HELP":
        HELP()
    elif uinp == "EXIT":
        EXIT()
    elif uinp == "WEB":
        WEB()   
    #elif uinp == "COPY":
        COPY()  
    elif uinp == "ABOUT":
        ABOUT()  
    elif uinp == "PYTHON":      
        c_py()  
    elif uinp == "PYTHON VERSION":
        py_ver()
    elif uinp == "CLEAR":
       CLEAR()       
    elif uinp == "C++":
        c_cpp()
    elif uinp == "C":
        c_c()
    elif uinp == "C#":
        c_cs()
    elif uinp == "FILES WEB":
        c_web()
    elif uinp == "S":
        c_asm()
    #elif uinp == "WINDOW":
       #Window()
    elif  uinp == "BIN":
       c_bin() 
    elif  uinp == "ISO":
       c_iso()
    elif  uinp == "ZIP":
       c_zip()
    elif  uinp == "RAR":
       c_rar()
    elif  uinp == "PNG":
       c_png()
    elif uinp == "WRITE":
        WRITE()          
    elif uinp == "READ":
        READ()                              
    else:                                                       #*****    ELSE    *****#
        print("INPUT ERROR")
        time.sleep(1)
        START1()     



def START1():             #DONE
    print("-----------------------------------------")
    uinp = str(input("What do you want to do?: "))
    print("-----------------------------------------")
    if uinp == "CREATE FOLDER":
        CREATE_FOLDER()
    elif uinp == "DELETE FOLDER":
        DELETE_FOLDER()
    elif uinp == "DIR":
        DIR()
    elif uinp == "HELP":
        HELP()
    elif uinp == "EXIT":
        EXIT()     
    elif uinp == "WEB":
        WEB()
    #elif uinp == "COPY":
        #COPY()  
    elif uinp == "ABOUT":
        ABOUT() 
    elif uinp == "PYTHON":      
        c_py()    
    elif uinp == "PYTHON VERSION":
        py_ver()
    elif uinp == "CLEAR":
       CLEAR()    
    elif uinp == "C++":
        c_cpp()
    elif uinp == "C":
        c_c()
    elif uinp == "C#":
        c_cs()
    elif uinp ==  "FILES WEB":
        c_web()
    elif uinp == "S":
        c_asm()
    #elif  uinp == "WINDOW":
       #Window()
    elif  uinp == "BIN":
       c_bin() 
    elif  uinp == "ISO":
       c_iso()
    elif  uinp == "ZIP":
       c_zip()
    elif  uinp == "RAR":
       c_rar()
    elif  uinp == "PNG":
       c_png()          
    elif uinp == "WRITE":
        WRITE()
    elif uinp == "READ":
        READ()              
    else:                                                       #*****    ELSE    *****#
        print("INPUT ERROR")
        time.sleep(1)
        START1()          

def HELP():            #DONE
   print("Commands:")
   print("CREATE FOLDER = Creates a folder")
   print("DELETE FOLDER = Deletes a folder")
   print("DIR = Shows the content of a folder")
   print("WEB = OPEN A WEB DIRECTION")
   print("EXIT = EXIT")
   print("HELP = Shows the commands")
   print("WEB = OPEN A WEB DIRECTION")
   print("ABOUT = ABOUT PyDOS!")
   print("PYTHON VERSION = SEE THE PYTHON VERSION")
   print("CLEAR = CLEARS THE CONSOLE")
   print("READ = READS A FILE")
   print("WRITE = CREATES A DOCUMENT")
   print("PYTHON = CREATES A PYTHON FILE")
   print("C++ = CREATES A C++ FILE")
   print("C# = CREATES A C# FILE")
   print("WEB FILE = CREATES HTML, CSS AND JAVASCRIPT FILES")
   print("C = CREATES A C FILE")
   print("S  = CREATES A ASSAMBLY FILE")
   print("BIN = CREATES A BIN FILE")
   print("ISO = CREATES A ISO FILE")
   print("ZIP = CREATES A ZIP FILE")
   print("RAR = CREATES A RAR FILE")
   print("PNG = CREATES A PNG FILE")
   #print("WINDOW = CREATES A WINDOW")
   print("-----------------------------")
   START1()

#Functions:   ############################################################################

def CLEAR():
    os.system('cls' if os.name == 'nt' else 'clear')
    START1()



def CREATE_FOLDER(): #DONE
    print("Enter the name of the folder you want to create: ")
    folder_name = input()
    os.mkdir(folder_name)
    print("Folder created successfully!")
    time.sleep(2)
    #os.system('cls')
    START1()

def COPY(): #FIX DOESN'T WORK  ############################################################
        source = input("Enter the source file path: ")
        destination = input("Enter the destination file path: ")
        try:
            with open(source, 'rb') as src_file:
                with open(destination, 'wb') as dest_file:
                    dest_file.write(src_file.read())
            print("File copied successfully!")
        except FileNotFoundError:
            print("Source file not found!")
        except Exception as e: 
            print(f"An error occurred: {e}")
        time.sleep(2)
        START1()
     
def DELETE_FOLDER():  #DONE
    print("Enter the name of the folder you want to delete: ")
    folder_name = input()
    os.rmdir(folder_name)
    print("Folder deleted successfully!")
    time.sleep(2)
    #os.system('cls')
    START1()
def DIR(): #DONE
    print("Enter the name of the folder you want to see the content: ")
    folder_name = input()
    print("The content of the folder is: ")
    os.system('dir ' + folder_name)
    def action_after_dir():
     action_afrt_dir = str(input("Do you want to do something else? [Y/N]: "))
     if action_after_dir == "Y" or "y":
        #os.system('cls')
        START1()
     elif action_after_dir == "N" or "n":
        sys.exit()
        #START1()
     else:
        print("Invalid input!")
        time.sleep(2)
        #os.system('cls')     
        #sys.exit()
        START1()
    action_after_dir()
    START1()

def ABOUT():                              ### ABOUT | ABOUT | ABOUT ###
    print(f"PyDOS Version: " + PyDOSversion)
    print("PyDOS was created by GAEL ROCCA")
    time.sleep(2)
    print(f"PYTHON VERSION: " + platform.python_version())
    time.sleep(3)
    webbrowser.open("https://www.youtube.com/channel/UC0vb8a1i1zc8Y0WIc4Ix_eg")
    time.sleep(1)
    START1()   

def py_ver():
    print(f"PYTHON VERSION: " + platform.python_version())
    time.sleep(2)
    START1()

def Window():   # DEBUG ONLY FIX
   window = Tk()
   geo = str(input("SET THE GEOMETRY OF THE WINDOW: "))
   window.geometry(geo)
   tit = str(input("SET THE TITLE OF THE WINDOW: "))
   window.title(tit)
   window.mainloop()
   if window.quit == True:
       None
       START1()
   else:
      START1() 

def READ():
    file_path = str(input("SET THE FILE THAT YOU WANT TO SEE ITS CONTENT: "))
    
    with open(file_path, 'r') as file:
        content = file.read()
        print("-------------------------------------------------------------------------------------------")
        print("CONTENT:")
        print("-------------------------------------------------------------------------------------------")
        print(content)
        time.sleep(2)
        if KeyboardInterrupt:
            START1()
        else:
            None
    if FileNotFoundError:
        return f"The file at {file_path} does not exist."
        START1()



#CREATE FILES:                                                                        ##########################

def c_py():
  file_name = input("Enter the name of the file you want to create: ")
  with open(file_name + '.py', 'w') as file:
    file.write("")
  print("File created successfully!")
  time.sleep(2) 
  START1()

def c_cpp():
  file_name = input("Enter the name of the file you want to create: ")
  with open(file_name + '.cpp', 'w') as file:
    file.write("")
  print("File created successfully!")
  time.sleep(2) 
  START1()

def c_c():
  file_name = input("Enter the name of the file you want to create: ")
  FILE_PATH = input("ENTER PATH: ")
  with open(file_name + '.c', 'w') as file:
    file.write(FILE_PATH)
  print("File created successfully!")
  time.sleep(2) 
  START1()

def c_cs():
  file_name = input("Enter the name of the file you want to create: ")
  with open(file_name + '.cs', 'w') as file:
    file.write("")
  print("File created successfully!")
  time.sleep(2) 
  START1()

def c_web():
    file_name = input("Enter the name of the file you want to create (HTML): ")
    with open(file_name + '.html', 'w') as file:
     file.write("")
    print("File created successfully!")
    time.sleep(0) 
    
    file_name = input("Enter the name of the file you want to create (CSS): ")
    with open(file_name + '.css', 'w') as file:
     file.write("")
    print("File created successfully!")
    time.sleep(0) 
    
    file_name = input("Enter the name of the file you want to create (JavaScript): ")
    with open(file_name + '.js', 'w') as file:
     file.write("")
    print("File created successfully!")
    time.sleep(0.75) 
    
    action = str(input("DO YOU WANT TO CREATE A .JSON FILE? [Y/N]: "))

    def c_json():
        file_name = input("Enter the name of the file you want to create (JSON): ")
        with open(file_name + '.json', 'w') as file:
         file.write("")
        print("File created successfully!")
        time.sleep(0)

    if action == 'Y':
        file_name = input("Enter the name of the file you want to create (JSON): ")
        with open(file_name + '.json', 'w') as file:
         file.write("")
        print("File created successfully!")
        time.sleep(2) 
        START1()
    elif action == 'N':
        time.sleep(0.25)
        START1()
    else:
        START1()

def c_asm():
    file_name = input("Enter the name of the file you want to create (Assambly): ")
    with open(file_name + '.s', 'w') as file:
     file.write("")
    print("File created successfully!")
    time.sleep(2) 
    START1()

def c_bin():
    file_name = input("Enter the name of the file you want to create (Bin): ")
    with open(file_name + '.bin', 'w') as file:
     file.write("")
    print("File created successfully!")
    time.sleep(2) 
    START1()

def c_iso():
    file_name = input("Enter the name of the file you want to create (ISO): ")
    with open(file_name + '.iso', 'w') as file:
     file.write("")
    print("File created successfully!")
    time.sleep(2) 
    START1()

def c_zip():
    file_name = input("Enter the name of the file you want to create (ZIP): ")
    with open(file_name + '.zip', 'w') as file:
     file.write("")
    print("File created successfully!")
    time.sleep(2) 
    START1()

def c_rar():
    file_name = input("Enter the name of the file you want to create (RAR): ")
    with open(file_name + '.rar', 'w') as file:
     file.write("")
    print("File created successfully!")
    time.sleep(2) 
    START1()

def c_png():
    file_name = input("Enter the name of the file you want to create (PNG): ")
    with open(file_name + '.png', 'w') as file:
     file.write("")
    print("File created successfully!")
    time.sleep(2) 
    START1()               

#PROGRAMS:

def WRITE():
    """
    Function to write content to a Microsoft Word document (.docx).
    
    :param file_name: The name of the file to create or overwrite.
    :param content: A string of content to add to the document.
    """
    file_name = str(input("SET A NAME FOR THE DOCUMENT: "))
    content = str(input("CONTENT: "))
    ext = str(input("Put the EXTENTION (EX: '.docx' ) : "))

    with open(file_name + ext, 'w') as file:
     file.write(content)
    print("File created successfully!")
    time.sleep(0) 
    #START1()


    print(f"Document '{file_name}' has been created with the content.")
    START1()



START() #Starts the program